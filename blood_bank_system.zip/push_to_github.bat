@echo off
title Push Blood Bank System to GitHub
echo ======================================================================
echo   PUSH BLOOD BANK MANAGEMENT SYSTEM TO GITHUB
echo ======================================================================
echo.
echo Your GitHub username is: adityadube16-maker
echo.
echo If you haven't already, please create a new empty repository at:
echo   https://github.com/new
echo with Repository Name: blood-bank-system
echo.
echo ======================================================================
echo.
set /p REPO_URL="Enter your GitHub Repo URL (or press Enter for https://github.com/adityadube16-maker/blood-bank-system.git): "
if "%REPO_URL%"=="" set REPO_URL=https://github.com/adityadube16-maker/blood-bank-system.git

echo.
echo Configuring remote repository...
git remote remove origin 2>nul
git remote add origin %REPO_URL%
git branch -M main

echo.
echo Pushing code to GitHub...
git push -u origin main

echo.
echo ======================================================================
echo Code successfully pushed to GitHub!
echo ======================================================================
pause
